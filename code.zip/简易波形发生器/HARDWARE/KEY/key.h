#ifndef __key_H
#define	__key_H
#include "sys.h"

#define key0 GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_0)
#define key1 GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_1)
#define key2 GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_2)
#define key3 GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_3)

void Key_Init(void);
u8 keyscan(void);
#endif
