#ifndef __DAC_H
#define __DAC_H	 
#include "sys.h"	    		    

void Dac2_Init(void);
#endif

















