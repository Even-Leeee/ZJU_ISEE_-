#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"
 
void TIM2_CH1_PWM_Init(u16 arr,u16 psc);	
#endif























