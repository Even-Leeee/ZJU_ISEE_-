#ifndef __DMA_H
#define	__DMA_H	   
#include "sys.h"	    					    

void MYDMA_Config(u32 cpar,u32 cmar,u16 cndtr);
		   
#endif




