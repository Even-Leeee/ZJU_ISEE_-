#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "time41.h"
#include "stdio.h"
#include "LCD.h"
volatile uint32_t TIM5OverflowCount = 0;    // ?????
volatile uint32_t Last_Capture = 0;
volatile uint32_t Capture = 0;
volatile uint64_t periodTicks = 0;          // ?????          // ??????
double frequency;  

u8 mode=1;
uint8_t i_main;
u8 captureflag=0;
u8 flag=0;
volatile uint8_t captureFlag = 0; 

volatile uint32_t pulse_count = 0;    
volatile uint64_t current_freq = 0;              
volatile uint32_t tim4_overflow_count = 0; 
uint64_t last_cnt=0;

u8 str[20];
//��ʱ���ж�ʵ��-�⺯���汾
//STM32F4����-�⺯���汾
//https://shop58085959.taobao.com		
int main(void)
{  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	delay_init(168);  //��ʼ����ʱ����
	uart_init(115200);		//��ʼ�����ڲ�����Ϊ115200
	LED_Init();				//��ʼ��LED�˿�
	LCD_Init();
	TIM4_InputCapture_Init();
	TIM5_Init() ;
	TIM3_GateTimer_Init();
	//TIM4_ExtClock_Init();
	
	while(1)
	{
		if(flag){
			flag=0;
			
			
			TIM_Cmd(TIM5,DISABLE);
			TIM_Cmd(TIM4,DISABLE);
			TIM_Cmd(TIM3,DISABLE);
			
			if (mode==1) mode=2;
			else if (mode==2) mode=1;
			
			TIM_SetCounter(TIM3,0);
			TIM_SetCounter(TIM4,0);
			TIM_SetCounter(TIM5,0);
			
			if(mode==1){
			TIM5OverflowCount = 0;
			Last_Capture = 0;
			Capture = 0;
			periodTicks = 0;
			captureFlag = 0; 
			frequency=0;
				
			TIM_DeInit(TIM4);
			TIM4_InputCapture_Init();
			TIM_Cmd(TIM5,ENABLE);
			TIM_Cmd(TIM3,ENABLE);
			printf("change1");
			}else{
			last_cnt=0;
			tim4_overflow_count = 0; 
			pulse_count = 0;
			current_freq = 0; 
			captureflag=0;
			TIM_Cmd(TIM5,DISABLE);
			TIM_DeInit(TIM4);
			TIM_Cmd(TIM3,ENABLE);
			TIM4_ExtClock_Init();
			printf("change2");
			}
		}
	};
}

void TIM4_IRQHandler(void) {
		if(mode==1){
		if (TIM_GetITStatus(TIM4, TIM_IT_CC2) != RESET)
		{
			Capture=TIM_GetCounter(TIM5);
			periodTicks=TIM5OverflowCount*10000+Capture-Last_Capture;
			frequency=4000000.f/(double)periodTicks;
			TIM5OverflowCount=0;
			Last_Capture=Capture;
			TIM_ClearITPendingBit(TIM4, TIM_IT_CC2);
			TIM_ClearITPendingBit(TIM4, TIM_IT_Update); 
		}
	}else{
		    if (TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET) {
        tim4_overflow_count++;               
        TIM_ClearITPendingBit(TIM4, TIM_IT_Update);  
				TIM_ClearITPendingBit(TIM4, TIM_IT_CC2);
			}
	}
}


void TIM5_IRQHandler(void) {
    if (TIM_GetITStatus(TIM5, TIM_IT_Update) != RESET) {
			TIM5OverflowCount++;
			TIM_ClearITPendingBit(TIM5, TIM_IT_Update);
		}
}


void TIM3_IRQHandler(void) {
		if(mode==2){
    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET) {
				if(captureflag==0){
					captureflag=1;
					TIM_SetCounter(TIM4,0);
					tim4_overflow_count=0;
					TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
				}else{
				uint64_t cnt=TIM_GetCounter(TIM4);
        uint64_t total_count = tim4_overflow_count * 65536UL+cnt-last_cnt ;
        current_freq = total_count /1.0;
				//printf("F_high: %llu Hz\r\n", current_freq);
				sprintf((char*)str,"F_high:%llu    ",current_freq);
				//LCD_Clear(WHITE);
				LCD_ShowString(30,80,200,16,16,str);		//��ʾLCD ID	  
				last_cnt=cnt;			
        tim4_overflow_count = 0;
				//premode=mode;
				TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
					
				if(current_freq<1200) flag=1;
					
					current_freq=0;
				}
			}
    }else{
			if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
			{
			if(captureflag==0){
				captureflag=1;
				TIM_SetCounter(TIM4,0);
				TIM_SetCounter(TIM5,0);
				Last_Capture=0;
				TIM5OverflowCount=0;
				periodTicks = 0;
				TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
			}else{
				i_main++;
				if(i_main==3){
				//printf("F_low: %.4lf Hz\r\n",frequency);
				sprintf((char*)str,"F_low:%.4lf    ",frequency);
				//LCD_Clear(WHITE);
				LCD_ShowString(30,80,200,16,16,str);		//��ʾLCD ID
				i_main=0;
				}					
			if(frequency>1200)
			{	
			TIM_Cmd(TIM5,DISABLE);
			TIM_Cmd(TIM4,DISABLE);
			TIM_Cmd(TIM3,DISABLE);
			flag=1;
			}
			TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
			}		
		}
		}
}

