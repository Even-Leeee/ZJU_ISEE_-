#include "stdio.h"  
#include "stm32f4xx.h"
void usart_set(u32 bound);
