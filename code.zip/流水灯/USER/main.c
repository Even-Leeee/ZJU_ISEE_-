#include "sys.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "timer.h"

#include "key.h"

int mode;//��ˮ��ģʽ��ȡֵΪ0 1 2 3 �ֱ��Ӧ�Զ���������1s �� �Զ�˫������0.5s���ֶ����ơ��ֶ�˫�ơ�����ע�⵽ż������˫�ƣ���������˫�ơ�
int state;//��ˮ��״̬�������ƶ�Ӧ����״̬��
 
//��ʱ���ж�ʵ��-�⺯���汾
//STM32F4����-�⺯���汾
//https://shop58085959.taobao.com		
int main(void)
{ 
    u8 key;
    mode = 1;
    state = 0;
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	delay_init(168);  //��ʼ����ʱ����
	LED_Init();				//��ʼ��LED�˿�
    
    Key_Init();         //��ʼ���밴�����ӵ�Ӳ���ӿ�

 	TIM3_Int_Init(5000-1,8400-1);	//��ʱ��ʱ��84M����Ƶϵ��8400������84M/8400=10Khz�ļ���Ƶ�ʣ�����5000��Ϊ500ms     
    delay_ms(50);
	while(1)
	{
		key = keyscan();
        if(key)
        {
            switch(key)
            {
                case 1://key = 1˵����ģʽmode�л�����ʱ״̬Ҫ++
                    mode = (mode + 1) % 4;
                    state = 0;
                    break;
                case 2:
                    if(mode > 1)//key=2˵�����ֶ�state�л���ֻ�����ֶ���mode>1ʱ�ſ���
                    {
                        state = (state + 1) %6;
                    }
                    break;
            }
        }
        
        //modeΪ0��2ʱ�ǵ�������1��3ʱ��˫����
        if(mode % 2 == 0)
        {
            switch(state)
            {
                case 0:
                    GPIO_ResetBits(GPIOF,GPIO_Pin_1);//�����������������GPIO reset������͵�ƽ������set������ߵ�ƽϨ��
                    GPIO_SetBits(GPIOF,GPIO_Pin_2);
                    GPIO_SetBits(GPIOF,GPIO_Pin_3);
                    GPIO_SetBits(GPIOF,GPIO_Pin_4);
                    GPIO_SetBits(GPIOF,GPIO_Pin_5);
                    GPIO_SetBits(GPIOF,GPIO_Pin_6);
                    break;
                
                case 1:
                    GPIO_SetBits(GPIOF,GPIO_Pin_1);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_2);
                    GPIO_SetBits(GPIOF,GPIO_Pin_3);
                    GPIO_SetBits(GPIOF,GPIO_Pin_4);
                    GPIO_SetBits(GPIOF,GPIO_Pin_5);
                    GPIO_SetBits(GPIOF,GPIO_Pin_6);
                    break;
                
                case 2:
                    GPIO_SetBits(GPIOF,GPIO_Pin_1);
                    GPIO_SetBits(GPIOF,GPIO_Pin_2);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_3);
                    GPIO_SetBits(GPIOF,GPIO_Pin_4);
                    GPIO_SetBits(GPIOF,GPIO_Pin_5);
                    GPIO_SetBits(GPIOF,GPIO_Pin_6);
                    break;
                
                case 3:
                    GPIO_SetBits(GPIOF,GPIO_Pin_1);
                    GPIO_SetBits(GPIOF,GPIO_Pin_2);
                    GPIO_SetBits(GPIOF,GPIO_Pin_3);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_4);
                    GPIO_SetBits(GPIOF,GPIO_Pin_5);
                    GPIO_SetBits(GPIOF,GPIO_Pin_6);
                    break;
                
                case 4:
                    GPIO_SetBits(GPIOF,GPIO_Pin_1);
                    GPIO_SetBits(GPIOF,GPIO_Pin_2);
                    GPIO_SetBits(GPIOF,GPIO_Pin_3);
                    GPIO_SetBits(GPIOF,GPIO_Pin_4);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_5);
                    GPIO_SetBits(GPIOF,GPIO_Pin_6);
                    break;
                
                case 5:
                    GPIO_SetBits(GPIOF,GPIO_Pin_1);
                    GPIO_SetBits(GPIOF,GPIO_Pin_2);
                    GPIO_SetBits(GPIOF,GPIO_Pin_3);
                    GPIO_SetBits(GPIOF,GPIO_Pin_4);
                    GPIO_SetBits(GPIOF,GPIO_Pin_5);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_6);
                    break;
                    
            }
        }
        //modeΪ
        else if(mode % 2 ==1)
        {
            switch(state)
            {
                case 0:
                    GPIO_ResetBits(GPIOF,GPIO_Pin_1);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_2);
                    GPIO_SetBits(GPIOF,GPIO_Pin_3);
                    GPIO_SetBits(GPIOF,GPIO_Pin_4);
                    GPIO_SetBits(GPIOF,GPIO_Pin_5);
                    GPIO_SetBits(GPIOF,GPIO_Pin_6);
                    break;
                
                case 1:
                    GPIO_SetBits(GPIOF,GPIO_Pin_1);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_2);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_3);
                    GPIO_SetBits(GPIOF,GPIO_Pin_4);
                    GPIO_SetBits(GPIOF,GPIO_Pin_5);
                    GPIO_SetBits(GPIOF,GPIO_Pin_6);
                    break;
                
                case 2:
                    GPIO_SetBits(GPIOF,GPIO_Pin_1);
                    GPIO_SetBits(GPIOF,GPIO_Pin_2);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_3);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_4);
                    GPIO_SetBits(GPIOF,GPIO_Pin_5);
                    GPIO_SetBits(GPIOF,GPIO_Pin_6);
                    break;
                
                case 3:
                    GPIO_SetBits(GPIOF,GPIO_Pin_1);
                    GPIO_SetBits(GPIOF,GPIO_Pin_2);
                    GPIO_SetBits(GPIOF,GPIO_Pin_3);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_4);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_5);
                    GPIO_SetBits(GPIOF,GPIO_Pin_6);
                    break;
                
                case 4:
                    GPIO_SetBits(GPIOF,GPIO_Pin_1);
                    GPIO_SetBits(GPIOF,GPIO_Pin_2);
                    GPIO_SetBits(GPIOF,GPIO_Pin_3);
                    GPIO_SetBits(GPIOF,GPIO_Pin_4);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_5);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_6);
                    break;
                
                case 5:
                    GPIO_ResetBits(GPIOF,GPIO_Pin_1);
                    GPIO_SetBits(GPIOF,GPIO_Pin_2);
                    GPIO_SetBits(GPIOF,GPIO_Pin_3);
                    GPIO_SetBits(GPIOF,GPIO_Pin_4);
                    GPIO_SetBits(GPIOF,GPIO_Pin_5);
                    GPIO_ResetBits(GPIOF,GPIO_Pin_6);
                    break;
                    
            }
        }
    }
}
