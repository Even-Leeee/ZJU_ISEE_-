#ifndef __key_H
#define	__key_H
#include "sys.h"

#define key0 GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_7)
#define key1 GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_9)

void Key_Init(void);
u8 keyscan(void);
#endif
