#ifndef __LED_H
#define __LED_H
#include "sys.h"
/*
#ifndef	__LED_H
#define	__LED_H
#include "sys.h"
*/
//////////////////////////////////////////////////////////////////////////////////	 
 
//LED��������	   
//STM32F4����-�⺯���汾
//https://shop58085959.taobao.com									  
////////////////////////////////////////////////////////////////////////////////// 	


//LED�˿ڶ���
#define LED1 PFout(9)	  // D1
#define LED2 PFout(10)	// D2	 

void LED_Init(void);//��ʼ��		 				    
#endif
